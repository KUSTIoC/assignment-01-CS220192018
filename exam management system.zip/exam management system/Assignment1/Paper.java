
package Package;
public class Paper {  
    private String paper_title;
    private int paper_id;
    private boolean iscollected;
    private Date dateofpaper;
    private Time timeofpaper;
    private int course_code;
    private String course_incharger;
    private String program;
    private int no_of_student;
    private String semester;
    private String type_exam;
    private String invigilator;
    private String location;
   
   
    public Paper(String paper_title,Date dateofpaper,Time timeofpaper ,String course_incharger,String program,String semester,String type_exam,String invigilator,String location,int paper_id,int course_code,int no_of_student) {
        this.paper_title = paper_title;
        this.dateofpaper=dateofpaper;
        this.timeofpaper=timeofpaper;
        this.course_incharger=course_incharger;
        this.program=program;
        this.semester=semester;
        this.type_exam=type_exam;
        this.invigilator=invigilator;
        this.location=location;
        this.iscollected=false;
        this.paper_id=paper_id;
        this.course_code=course_code;
        this.no_of_student=no_of_student;
    
}

    public Date getDateofpaper() {
        return dateofpaper;
    }

    public Time getTimeofpaper() {
        return timeofpaper;
    }

    public int getCourse_code() {
        return course_code;
    }

    public String getCourse_incharger() {
        return course_incharger;
    }

    public String getProgram() {
        return program;
    }

    public int getNo_of_student() {
        return no_of_student;
    }

    public String getSemester() {
        return semester;
    }

    public String getType_exam() {
        return type_exam;
    }

    public String getInvigilator() {
        return invigilator;
    }

    public String getLocation() {
        return location;
    }
    

    public String getPaper_title() {
        return paper_title;
    }
    public int getPaper_id() {
        return paper_id;
    }
    public void setIscollected(boolean iscollected)
    {
        this.iscollected=iscollected;
    }


    public boolean getIscollected() {
        return iscollected;
    }
    
    @Override
    public String toString() {
        return  String.format("paper_title= %s , paper id= %d , iscoolected= %b , dateofpaper= %s , timeofpaper= %s ,  course code= %d , course incharger= %s , program= %s , no of student= %d , semester= %s ,  type exam= %s , invigilator= %s , location= %s" ,paper_title,paper_id,iscollected,dateofpaper,timeofpaper,course_code,course_incharger,program,no_of_student,semester,type_exam,invigilator,location);
    }
    
}
