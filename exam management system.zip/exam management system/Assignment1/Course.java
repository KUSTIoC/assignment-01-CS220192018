
package Package;
public class Course {
    private  final String course_Name;
    private String course_code;
    private String programName;
    private int courseoffer;

    public Course(String course_Name, String course_code, int courseOffer) {
        this.course_Name = course_Name;
        this.course_code = course_code;
         this.courseoffer = courseOffer;
    }

    public String getCourse_Name() {
        return course_Name;
    }

    public String getCourse_code() {
        return course_code;
    }

    public void setCourse_code(String course_code) {
        this.course_code = course_code;
    }

    @Override
    public String toString() {
        return "Course{" + "course_Name=" + course_Name + ", course_code=" + course_code + ", programName=" + programName + ", courseoffer=" + courseoffer + '}';
    }
    
    
    
    
    
    
}
