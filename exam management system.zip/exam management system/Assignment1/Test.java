
package Package;

public class Test {

   
    public static void main(String[] args) {
        Date date=new Date(23,03,2020);
        Time time=new Time(6,25,30);
       Paper paper1=new Paper(" SPRING",date,time,"ALI ZEB","MCS","2ND","MID TERM","ZEESHAN IQBAL","KUST",1120,125,50);
        Paper paper2=new Paper(" SPRING",date,time,"ALI ZEB","MCS","2ND","MID TERM","ZEESHAN IQBAL","KUST",1123,123,50);
         Paper paper3=new Paper(" SPRING",date,time,"ALI ZEB","MCS","2ND","MID TERM","ZEESHAN IQBAL","KUST",1125,124,50);
         Course course1=new Course("WEB DESIGNING","125",2019);
         Course course2=new Course("COMMUNICATION SKILL","123",2019);
         paper1.setIscollected(true);
         paper2.setIscollected(true);
         paper3.setIscollected(false);
         course1.setCourse_code("CS213");  
         course2.setCourse_code("CS210");
         System.out.println(paper1);
         System.out.println(paper2);
         System.out.println(paper3);
         System.out.println(course1);
         System.out.println(course2);
    }
    }
    

